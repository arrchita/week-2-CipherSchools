function Pizza(){
    return(
    <div class='pizza'>
      <h1>Pizza</h1>
    </div>
  )
}
ReactDOM.render(Pizza(), document.getElementById('root'));